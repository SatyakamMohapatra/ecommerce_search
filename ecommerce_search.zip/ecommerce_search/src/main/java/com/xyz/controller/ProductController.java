package com.xyz.controller;

import java.net.URI;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xyz.entity.Product;
import com.xyz.service.NoFilterFound;
import com.xyz.service.ProductService;

@RestController
@RequestMapping("/api/v1/product")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	public ProductController(ProductService productService) {
		this.productService = productService;
	}

	@PostMapping
	public ResponseEntity<String> save(@RequestBody Product product) {
		Long sku = productService.save(product);
		return new ResponseEntity<>(URI.create("/api/v1/product/"+sku).toString(),HttpStatus.CREATED);
	}
	
	@PatchMapping("/update")
	public ResponseEntity<String> update(@RequestBody Product product) {
		Long sku = productService.save(product);
		return new ResponseEntity<>(String.format("product %s updated", sku),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/id")
	public ResponseEntity<Product> getBySKU(@PathVariable String sku) {
		return new ResponseEntity<>(productService.get(Long.valueOf(sku)),HttpStatus.OK);
	}
	
	@DeleteMapping("/id")
	public ResponseEntity<String> deleteBySKU(@PathVariable String sku) {
		productService.delete(Long.valueOf(sku));
		return new ResponseEntity<>(sku+ " removed",HttpStatus.ACCEPTED);
	}
	
	@GetMapping
	public ResponseEntity<List<Product>> getAll() {
		return new ResponseEntity<>(productService.getAll(),HttpStatus.OK);
	}
	
	@GetMapping("/groupBy/{filter}")
	public ResponseEntity<Map<Object, List<Product>>> getProducts(@PathVariable String filter) throws NoFilterFound {
		return new ResponseEntity<>(productService.findBy(filter),HttpStatus.OK);
	}
}
