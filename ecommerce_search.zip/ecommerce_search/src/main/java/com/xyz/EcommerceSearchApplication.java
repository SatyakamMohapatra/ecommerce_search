package com.xyz;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.xyz.util.DbRefresh;

@SpringBootApplication
public class EcommerceSearchApplication implements CommandLineRunner {


	public static void main(String[] args) {
		SpringApplication.run(EcommerceSearchApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		int hours = 2 * 3600 * 1000;
		new DbRefresh(hours);
	}

}
