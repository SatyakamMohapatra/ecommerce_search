package com.xyz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.xyz.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long>{
	
	@Query("SELECT p FROM PRODUCT p JOIN FATCH p.brand WHERE p.brand_id = :brandid")
	List<Product> findByBrandid(@Param("brandid") Long brandid);
	
	@Query("SELECT p FROM PRODUCT p JOIN FATCH p.brand WHERE p.brand_id = :colorId")
	List<Product> findByColourid(@Param("colorId") Long colorId);
	
	@Query("SELECT p FROM PRODUCT p JOIN FATCH p.brand WHERE p.brand_id = :sizeId")
	List<Product> findBySizeid(@Param("sizeId") Long sizeId);
	
	List<Product> findByPrice(Double price);
}
