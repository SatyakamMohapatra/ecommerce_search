package com.xyz.util;

import java.util.Timer;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;

import com.xyz.service.ProductService;

public class DbRefresh{
	
	@Autowired
	private ProductService productService;
	
	private Timer timer;

    public DbRefresh(int hours) {
        timer = new Timer(); 
        timer.scheduleAtFixedRate(new DbRefreshTask(), 0, hours);
    }

    class DbRefreshTask extends TimerTask {
        @Override
        public void run() {
        	productService.refresh();
        }
    }
}
