package com.xyz.service;

public class NoFilterFound extends Exception {
	
	private static final long serialVersionUID = 1L;

	public NoFilterFound() {
		super("no filter found");
	}

}
