package com.xyz.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xyz.entity.Product;
import com.xyz.repository.ProductRepository;

@Service
public class ProductServicesImpl implements ProductService{
	
	public static List<Product> productsCache = new ArrayList<>();
	
	@Autowired
	private ProductRepository productRepository;
	
	public ProductServicesImpl(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@Override
	public Long save(Product product) {
		Product item = productRepository.save(product);
		refresh();
		return item.getSku();
	}

	@Override
	public void refresh() {
		productsCache.clear();
		productsCache.addAll(getAll());
	}

	@Override
	public Product get(Long sku) {
		return productRepository.findById(sku).orElse(new Product());
	}

	@Override
	public List<Product> getAll() {
		return productsCache;
	}

	@Override
	public void delete(Long sku) {
		refresh();
		productRepository.deleteById(sku);
	}

	@Override
	public Map<Object, List<Product>> findBy(String filter) throws NoFilterFound {
		List<Product> products= productsCache;
		if(filter.equalsIgnoreCase("size")) {
			return products.stream().collect(Collectors.groupingBy(Product::getSize));
		}else if (filter.equalsIgnoreCase("colour")) {
			return products.stream().collect(Collectors.groupingBy(Product::getColor));
		}else if (filter.equalsIgnoreCase("brand")) {
			return products.stream().collect(Collectors.groupingBy(Product::getBrand));
		}else if (filter.equalsIgnoreCase("price")) {
			return products.stream().collect(Collectors.groupingBy(Product::getPrice));
		}else {
			throw new NoFilterFound();
		}
	}

}
