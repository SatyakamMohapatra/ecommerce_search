package com.xyz.service;

import java.util.List;
import java.util.Map;

import com.xyz.entity.Product;

public interface ProductService {
	
	void refresh();
	
	Long save(Product product);
	
	Product get(Long sku);
	
	List<Product> getAll();

	void delete(Long sku);

	Map<Object, List<Product>> findBy(String filter) throws NoFilterFound;
}
